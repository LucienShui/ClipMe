<?php
/**
 * User: Lucien Shui
 * Date: 2018/7/23
 * Time: 22:35
 */
return array (
    'website' => 'http://clip.lucien.ink/',
);
?>